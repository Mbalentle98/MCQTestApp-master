﻿using Logic;
using System;
using System.Collections.Generic;

namespace ConsoleUI
{
    class Program
    {
        static TestController tc = new TestController();

        static void Main(string[] args)
        {
            tc.takeTest("Broe");
        }
    }
}
